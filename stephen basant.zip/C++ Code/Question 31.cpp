// 31. Program to Compare 2 Strings

#include <iostream>
using namespace std;

int main() {
    string str1, str2;

    // Taking input for first string
    cout << "Enter first string: ";
    cin >> str1;

    // Taking input for second string
    cout << "Enter second string: ";
    cin >> str2;

    // Comparing the two strings
    if (str1 == str2) {
        cout << "Both strings are equal." << endl;
    } else {
        cout << "Strings are not equal." << endl;
    }

    return 0;
}
