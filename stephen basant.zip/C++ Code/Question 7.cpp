//7. Program to Convert a Character to Uppercase if it is Lowercase

#include <iostream>
#include <cctype>  // For islower() and toupper()
using namespace std;

int main() {
    char ch;

    cout << "Enter a character: ";
    cin >> ch;

    // Check if lowercase
    if (islower(ch)) {
        ch = toupper(ch);   // Convert to uppercase
        cout << "Converted to uppercase: " << ch << endl;
    } else {
        cout << "Character is not lowercase. It is: " << ch << endl;
    }

    return 0;
}
