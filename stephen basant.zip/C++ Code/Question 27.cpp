// 27. Linear Search in an Array

#include <iostream>
using namespace std;

int main() {
    int n, x, pos = -1;
    cout << "Enter size of array: ";
    cin >> n;

    int arr[n];
    cout << "Enter array elements: ";
    for (int i = 0; i < n; i++) cin >> arr[i];

    cout << "Enter element to search: ";
    cin >> x;

    // Linear search
    for (int i = 0; i < n; i++) {
        if (arr[i] == x) {
            pos = i;
            break;
        }
    }

    if (pos == -1)
        cout << "Element not found\n";
    else
        cout << "Element found at index " << pos << endl;

    return 0;
}
