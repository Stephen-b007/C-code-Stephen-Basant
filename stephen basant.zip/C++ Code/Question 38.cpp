// 38. Add & Subtract 2 Complex Numbers

#include <iostream>
using namespace std;

struct Complex {
    float real, imag;
};

int main() {
    Complex c1, c2, sum, diff;

    cout << "Enter first complex number (real imag): ";
    cin >> c1.real >> c1.imag;

    cout << "Enter second complex number (real imag): ";
    cin >> c2.real >> c2.imag;

    sum.real = c1.real + c2.real;
    sum.imag = c1.imag + c2.imag;

    diff.real = c1.real - c2.real;
    diff.imag = c1.imag - c2.imag;

    cout << "Sum = " << sum.real << " + " << sum.imag << "i\n";
    cout << "Difference = " << diff.real << " + " << diff.imag << "i\n";

    return 0;
}
