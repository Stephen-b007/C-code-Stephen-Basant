// 44. Program to enter, simplify, and display a rational number
/*  A rational number = numerator/denominator. We simplify using GCD. */

#include <iostream>
using namespace std;

int gcd(int a, int b) {
    if (b == 0) return a;
    return gcd(b, a % b);
}

struct Rational {
    int num, den;
};

int main() {
    Rational r;
    cout << "Enter numerator: ";
    cin >> r.num;
    cout << "Enter denominator: ";
    cin >> r.den;

    int g = gcd(r.num, r.den);
    r.num /= g;
    r.den /= g;

    cout << "Simplified Rational Number = " << r.num << "/" << r.den << endl;
    return 0;
}
