//41. Program using pointer to structure

#include <iostream>
using namespace std;

struct Student {
    char name[30];
    int roll;
    float marks;
};

int main() {
    Student s;          // structure variable
    Student *ptr = &s;  // pointer to structure

    cout << "Enter name: ";
    cin >> ptr->name;
    cout << "Enter roll: ";
    cin >> ptr->roll;
    cout << "Enter marks: ";
    cin >> ptr->marks;

    cout << "\n--- Student Info ---\n";
    cout << "Name: " << ptr->name << endl;
    cout << "Roll: " << ptr->roll << endl;
    cout << "Marks: " << ptr->marks << endl;

    return 0;
}
