// 43. Program to display colors using enumerated types

#include <iostream>
using namespace std;

enum Colors { RED, GREEN, BLUE, YELLOW, BLACK, WHITE };

int main() {
    Colors c;

    cout << "Available colors:\n";
    for (int i = RED; i <= WHITE; i++) {
        c = (Colors)i;
        switch (c) {
            case RED: cout << "RED\n"; break;
            case GREEN: cout << "GREEN\n"; break;
            case BLUE: cout << "BLUE\n"; break;
            case YELLOW: cout << "YELLOW\n"; break;
            case BLACK: cout << "BLACK\n"; break;
            case WHITE: cout << "WHITE\n"; break;
        }
    }

    return 0;
}
