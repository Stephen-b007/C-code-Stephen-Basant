//6. Program to Convert an Integer into a Floating Point Number

#include <iostream>
using namespace std;

int main() {
    int num;
    float fnum;

    cout << "Enter an integer: ";
    cin >> num;

    // Convert integer to float
    fnum = static_cast<float>(num);

    cout << "The floating point value = " << fnum << endl;

    return 0;
}
