//37. Copy string into new string (Dynamic memory)

#include <iostream>
#include <cstring>
using namespace std;

int main() {
    char str[100];
    cout << "Enter a string: ";
    cin.getline(str, 100);

    // allocate memory dynamically
    char *copy = new char[strlen(str) + 1];

    strcpy(copy, str);  // copy string

    cout << "Copied string: " << copy;

    delete[] copy; // free memory
    return 0;
}
