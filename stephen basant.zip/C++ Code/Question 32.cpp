// 32. Program to Insert a String in the Main Text

#include <bits/stdc++.h>
using namespace std;

int main() {
    string str1("Hello World! ");
    string str2("GeeksforGeeks ");

    // Inserts str2 in str1 starting
    // from 6th index of str1
    str1.insert(6, str2);
    cout << str1;

    return 0;
}