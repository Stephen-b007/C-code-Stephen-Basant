//Q11. Program to sum the series: 1/1 + 2/2 + 3/3 + ... up to n terms

#include <iostream>
using namespace std;

int main() {
    int n;
    cout << "Enter number of terms: ";
    cin >> n;

    double sum = 0; // Store sum of series

    for (int i = 1; i <= n; i++) {
        sum += (double)i / i; // Each term is i/i = 1
    }

    cout << "Sum of series = " << sum << endl;

    return 0;
}
