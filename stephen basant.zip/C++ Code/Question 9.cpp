// Q9. Program to print 20 horizontal asterisks (*)

#include <iostream>
using namespace std;

int main() {
    // Loop runs 20 times
    for(int i = 0; i < 20; i++) {
        cout << "*"; // Print star
    }
    cout << endl; // Move to next line
    return 0;
}
