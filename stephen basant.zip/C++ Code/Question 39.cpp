// 39. Student info using structure

#include <iostream>
using namespace std;

struct Student {
    int roll;
    char name[50];
    float marks;
};

int main() {
    Student s;

    cout << "Enter roll no: ";
    cin >> s.roll;
    cin.ignore(); // clear buffer

    cout << "Enter name: ";
    cin.getline(s.name, 50);

    cout << "Enter marks: ";
    cin >> s.marks;

    cout << "\n--- Student Information ---\n";
    cout << "Roll: " << s.roll << "\n";
    cout << "Name: " << s.name << "\n";
    cout << "Marks: " << s.marks << "\n";

    return 0;
}
