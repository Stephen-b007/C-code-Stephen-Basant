// 42. Program to illustrate the use of arrays within structure

#include <iostream>
using namespace std;

struct Student {
    char name[30];
    int roll;
    float marks[5];  // array inside structure
};

int main() {
    Student s;
    cout << "Enter name: ";
    cin >> s.name;
    cout << "Enter roll: ";
    cin >> s.roll;

    cout << "Enter 5 subject marks: ";
    for (int i = 0; i < 5; i++)
        cin >> s.marks[i];

    cout << "\n--- Student Info ---\n";
    cout << "Name: " << s.name << ", Roll: " << s.roll << endl;
    cout << "Marks: ";
    for (int i = 0; i < 5; i++)
        cout << s.marks[i] << " ";

    return 0;
}
