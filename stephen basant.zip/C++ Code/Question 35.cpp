// 35. Program to Add 2 Integers using Pointer

#include <iostream>
using namespace std;

int main() {
    int a, b, sum;
    int *p1, *p2;

    cout << "Enter first number: ";
    cin >> a;
    cout << "Enter second number: ";
    cin >> b;

    p1 = &a;  // pointer points to a
    p2 = &b;  // pointer points to b

    sum = *p1 + *p2;  // dereferencing pointers

    cout << "Sum = " << sum << endl;

    return 0;
}
