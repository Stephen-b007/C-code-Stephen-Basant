// 41. Info of all students in class

#include <iostream>
using namespace std;

class Student {
private:
    char name[50];
    int roll;
    char city[50];
    int pin;

public:
    // Function to take input
    void getData() {
        cout << "Enter the name of student: ";
        cin >> name;
        cout << "Enter the Roll no.: ";
        cin >> roll;
        cout << "Enter the city: ";
        cin >> city;
        cout << "Enter the Pin code: ";
        cin >> pin;
    }

    // Function to display student info
    void show() {
        cout << "\nStudent Name: " << name << endl;
        cout << "Student Roll No.: " << roll << endl;
        cout << "Student City: " << city << endl;
        cout << "Student Pin Code: " << pin << endl;
    }
};

int main() {
    Student obj[2]; // array of 2 students

    // Input data for all students
    for (int i = 0; i < 2; i++) {
        cout << "\nEnter details of student " << i + 1 << ":\n";
        obj[i].getData();
    }

    // Display data of all students
    for (int i = 0; i < 2; i++) {
        cout << "\n--- Student Info " << i + 1 << " ---";
        obj[i].show();
    }

    return 0;
}
