//28. Transpose of 3×3 Matrix

#include <iostream>
using namespace std;

int main() {
    int mat[3][3];
    cout << "Enter elements of 3x3 matrix:\n";
    for (int i = 0; i < 3; i++)
        for (int j = 0; j < 3; j++)
            cin >> mat[i][j];

    cout << "Transpose matrix:\n";
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            cout << mat[j][i] << " "; // row-column swap
        }
        cout << endl;
    }
    return 0;
}
