// Q12. Program to print the pattern
/*A
  AB
  ABC
  ABCD
  ABCDE
  */

  #include <iostream>
using namespace std;

int main() {
    int rows = 5; // Number of rows in pattern

    // Outer loop for rows
    for (int i = 1; i <= rows; i++) {
        // Inner loop to print characters from 'A'
        for (int j = 0; j < i; j++) {
            cout << char('A' + j); // Convert number to alphabet
        }
        cout << endl; // Next line after each row
    }

    return 0;
}
