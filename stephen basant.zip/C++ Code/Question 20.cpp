// 20. Function Overloading (Static Polymorphism)

#include <iostream>
using namespace std;

// Overloaded functions
int add(int a, int b) {
    return a + b;
}

float add(float a, float b) {
    return a + b;
}

int main() {
    cout << "Addition of integers: " << add(5, 7) << endl;
    cout << "Addition of floats: " << add(3.5f, 2.5f) << endl;
    return 0;
}
