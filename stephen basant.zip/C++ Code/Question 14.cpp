// Q14. Program to calculate the average of first n natural numbers

#include <iostream>
using namespace std;

int main() {
    int n;
    cout << "Enter value of n: ";
    cin >> n;

    int sum = 0;

    // Loop to add first n natural numbers
    for (int i = 1; i <= n; i++) {
        sum += i;
    }

    double average = (double)sum / n; // Calculate average

    cout << "Average of first " << n << " natural numbers = " << average << endl;

    return 0;
}
