//5. Program to Display the Size of Every Data Type

#include <iostream>
using namespace std;

int main() {
    cout << "Size of char: " << sizeof(char) << " byte(s)" << endl;
    cout << "Size of int: " << sizeof(int) << " byte(s)" << endl;
    cout << "Size of float: " << sizeof(float) << " byte(s)" << endl;
    cout << "Size of double: " << sizeof(double) << " byte(s)" << endl;
    cout << "Size of long int: " << sizeof(long int) << " byte(s)" << endl;
    cout << "Size of short int: " << sizeof(short int) << " byte(s)" << endl;

    return 0;
}
