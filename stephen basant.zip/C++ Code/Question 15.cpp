// 15. Decimal to Binary Conversion

#include <iostream>
using namespace std;

int main() {
    int n;
    cout << "Enter a decimal number: ";
    cin >> n;

    string binary = "";  // binary number ko string me store karenge

    // Decimal ko binary me convert karne ka logic
    while (n > 0) {
        int r = n % 2;                // remainder lega (0 ya 1)
        binary = to_string(r) + binary; // string ke aage add karenge
        n = n / 2;                    // number ko divide karte rahenge
    }

    cout << "Binary equivalent: " << binary << endl;
    return 0;
}
