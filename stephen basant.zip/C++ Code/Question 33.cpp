// 33. Program to Sort Names of Students

#include <iostream>
#include <string>
#include <algorithm>  // for sort
using namespace std;

int main() {
    int n;
    cout << "Enter number of students: ";
    cin >> n;

    string names[100];
    cin.ignore(); // to clear buffer

    cout << "Enter names of students:\n";
    for (int i = 0; i < n; i++) {
        getline(cin, names[i]);
    }

    // sort names alphabetically
    sort(names, names + n);

    cout << "\nSorted names:\n";
    for (int i = 0; i < n; i++) {
        cout << names[i] << endl;
    }

    return 0;
}
