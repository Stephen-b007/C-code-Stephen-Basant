//17. Calendar of a Month

#include <iostream>
using namespace std;

int main() {
    int startDay, days;
    cout << "Enter start day of month (0=Sun, 1=Mon...6=Sat): ";
    cin >> startDay;
    cout << "Enter number of days in month: ";
    cin >> days;

    cout << "Sun Mon Tue Wed Thu Fri Sat\n";

    // Starting ke liye blank spaces
    for (int i = 0; i < startDay; i++) {
        cout << "    ";
    }

    // Days print karna
    for (int d = 1; d <= days; d++) {
        cout << d << "\t";
        if ((d + startDay) % 7 == 0)  // ek week complete ho gaya
            cout << endl;
    }

    return 0;
}
