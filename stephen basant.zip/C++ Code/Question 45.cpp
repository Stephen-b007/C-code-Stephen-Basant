// 45. Program to demonstrate function overloading in a class

/* Function Overloading = Same function name, different parameters. */

#include <iostream>
using namespace std;

class Math {
public:
    int add(int a, int b) {
        return a + b;
    }

    float add(float a, float b) {
        return a + b;
    }

    int add(int a, int b, int c) {
        return a + b + c;
    }
};

int main() {
    Math m;

    cout << "Sum of 2 int: " << m.add(5, 10) << endl;
    cout << "Sum of 2 float: " << m.add(2.5f, 3.7f) << endl;
    cout << "Sum of 3 int: " << m.add(1, 2, 3) << endl;

    return 0;
}
