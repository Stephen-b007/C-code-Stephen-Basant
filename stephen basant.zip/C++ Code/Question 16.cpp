//16. Largest of 10 Numbers using Ternary Operator

#include <iostream>
using namespace std;

int main() {
    int n, largest;
    cout << "Enter 10 numbers:\n";
    cin >> largest;  // pehle number ko largest maan lete hain

    for (int i = 1; i < 10; i++) {
        cin >> n;
        largest = (n > largest) ? n : largest; // ternary operator
    }

    cout << "Largest number is: " << largest << endl;
    return 0;
}
