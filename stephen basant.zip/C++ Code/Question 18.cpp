// 18. Area of Circle using Function

#include <iostream>
using namespace std;

// Function to calculate area
float areaOfCircle(float r) {
    return 3.14159 * r * r;
}

int main() {
    float radius;
    cout << "Enter radius of circle: ";
    cin >> radius;

    cout << "Area of circle = " << areaOfCircle(radius) << endl;
    return 0;
}

/*
Explanation (Hinglish):

Formula = π * r²

Function banaya areaOfCircle() jisme radius pass karte hain.

*/