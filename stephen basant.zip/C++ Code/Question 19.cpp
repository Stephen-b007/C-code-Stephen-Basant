// 19. Volume of Cuboid using Default Arguments

#include <iostream>
using namespace std;

// Function with default arguments
int volume(int l = 1, int b = 1, int h = 1) {
    return l * b * h;
}

int main() {
    cout << "Volume with default values = " << volume() << endl;
    cout << "Volume with l=5,b=3,h=2 = " << volume(5, 3, 2) << endl;
    return 0;
}
