//34. Program to Enter Multi-line Text and Display n Lines Starting from m-th Line

#include <iostream>
#include <string>
using namespace std;

int main() {
    int n, m, total;
    cout << "Enter total number of lines: ";
    cin >> total;
    cin.ignore();

    string lines[100];

    cout << "Enter the text (line by line):\n";
    for (int i = 0; i < total; i++) {
        getline(cin, lines[i]);
    }

    cout << "Enter starting line (m): ";
    cin >> m;
    cout << "Enter number of lines to display (n): ";
    cin >> n;

    cout << "\nOutput:\n";
    for (int i = m - 1; i < m - 1 + n && i < total; i++) {
        cout << lines[i] << endl;
    }

    return 0;
}
