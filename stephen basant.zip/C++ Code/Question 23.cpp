//23. Program to read and display n random numbers using an array

/* Logic: Use rand() function to generate random numbers and store in array. */

#include <iostream>
#include <cstdlib> // for rand()
#include <ctime>   // for time()
using namespace std;

int main() {
    int n;
    cout << "Enter number of random elements: ";
    cin >> n;

    int arr[n];
    srand(time(0)); // seed for random generator

    // Generate random numbers and store in array
    for (int i = 0; i < n; i++) {
        arr[i] = rand() % 100; // random number between 0-99
    }

    // Display array
    cout << "Random numbers are: ";
    for (int i = 0; i < n; i++) {
        cout << arr[i] << " ";
    }
    return 0;
}
 
