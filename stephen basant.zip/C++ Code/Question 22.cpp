// 22. Program to calculate exp(x, y) using recursive function

#include <iostream>
using namespace std;

// Recursive power function
int power(int x, int y) {
    if (y == 0)  // base case: anything power 0 is 1
        return 1;
    return x * power(x, y - 1); // recursive step
}

int main() {
    int base, exp;
    cout << "Enter base and exponent: ";
    cin >> base >> exp;
    cout << base << "^" << exp << " = " << power(base, exp);
    return 0;
}


